package com.hrm.controller;

import java.awt.font.ShapeGraphicAttribute;
import java.io.IOException;
import java.net.UnknownHostException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hrm.constants.EmployeeConstants;
import com.hrm.session.SharedObject;

/**
 * Servlet implementation class LogOutServlet
 */
@WebServlet("/LogOutServlet")
public class LogOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogOutServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SharedObject.deleteObjectFromSession(EmployeeConstants.EMPLOYEE_ID);
		SharedObject.deleteObjectFromSession(EmployeeConstants.ERROR_MSG_UI);
		RequestDispatcher forward=request.getRequestDispatcher("user.jsp");
		try {
		forward.forward(request, response);
		}
		catch(UnknownHostException uhex) {
			System.out.println(uhex);
		}
	}
	

}
