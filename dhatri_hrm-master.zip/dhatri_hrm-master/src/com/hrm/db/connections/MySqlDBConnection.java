/**
 * 
 */
package com.hrm.db.connections;

import java.sql.Connection;
import java.sql.DriverManager;

public class  MySqlDBConnection {

	static MySqlDBConnection mySQLDBInstance = new MySqlDBConnection();
	static Connection con;

	private MySqlDBConnection() {
		try {
			String password="root";
	 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hrm", "root", password);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static Connection getInstance() {

		return MySqlDBConnection.con;
	}
	
	public static void main(String[] args) {
		System.out.println(getInstance());
	}
}
